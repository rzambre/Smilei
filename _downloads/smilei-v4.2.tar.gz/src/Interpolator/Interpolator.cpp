#include "Interpolator.h"

#include <cmath>
#include <iostream>

#include "Params.h"
#include "Patch.h"

using namespace std;

Interpolator::Interpolator( Params &params, Patch *patch )
{
}

